Beams
Copyright (c) 2009, 2010, 2011, 2012, 2013 Philip Chimento

This is a laser beam profiler designed for use with cheap webcams. Commercial
laser beam profilers cost a lot of money although they perform fairly simple
calculations and often have horrible user interfaces. Optics researchers
everywhere will hopefully profit from an open-source solution designed for
inexpensive hardware.



