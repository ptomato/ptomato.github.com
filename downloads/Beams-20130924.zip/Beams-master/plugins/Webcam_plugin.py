info = {
    'id': 'webcam',
    'name': 'OpenCV',
    'description': 'Video camera interfacing through OpenCV',
    'module name': 'Webcam',
    'class name': 'Webcam',
    'author': 'Philip Chimento',
    'copyright year': '2011',
}
