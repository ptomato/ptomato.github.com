info = {
    'id': 'ds',
    'name': 'DirectShow',
    'description': 'Video camera interfacing through DirectShow',
    'module name': 'DirectShow',
    'class name': 'DirectShow',
    'author': 'Philip Chimento',
    'copyright year': '2011',
}
