info = {
    'id': 'dummy',
    'name': 'Dummy Gaussian',
    'description': 'Fake Gaussian data with uniform random noise',
    'module name': 'DummyGaussian',
    'class name': 'DummyGaussian',
    'author': 'Philip Chimento',
    'copyright year': '2011',
}
