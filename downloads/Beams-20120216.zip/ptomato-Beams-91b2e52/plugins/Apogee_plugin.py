info = {
    'id': 'apogee',
    'name': 'Apogee',
    'description': 'Apogee Alta or Ascent camera',
    'module name': 'ApogeeCam',
    'class name': 'ApogeeCam',
    'author': 'Philip Chimento',
    'copyright year': '2011',
}