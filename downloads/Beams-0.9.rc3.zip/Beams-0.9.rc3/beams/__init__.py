import MainWindow
__version__ = '0.9.rc3'
